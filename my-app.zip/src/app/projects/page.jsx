import AboutUs from "@/component/AboutUs";
import Project from "@/component/Project";

export default function ProjectPage() {
  return (
    <>
      <section className=" section ">
        <div className="container">
        <Project/>
        </div>
      </section>
    </>
  );
}
