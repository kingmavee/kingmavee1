export default function Skills(){
    return(
        <>
        </>
    )
}