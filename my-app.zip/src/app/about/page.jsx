import AboutUs from "@/component/AboutUs";

export default function AboutUsPage() {
  return (
    <>
      <section className=" section ">
        <div className="container">
          <AboutUs />
        </div>
      </section>
    </>
  );
}
