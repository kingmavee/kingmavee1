import LandingPage from "@/Component/Landing";



export default function Home() {
  return (
    <>
    
        <LandingPage />
    </>
  );
}
